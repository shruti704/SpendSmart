package com.example.incomeexpense.Adapters;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.incomeexpense.Activities.DisplayImageActivity;
import com.example.incomeexpense.R;

import java.util.List;

public class ImageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {

    private List<String> imageFileNames;

    public ImageAdapter(List<String> imageFileNames) {
        this.imageFileNames = imageFileNames;
    }

    @NonNull
    @Override
    public ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_rowchk, parent, false);

        return new ImageViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHolder holder, int position) {
        String imagePath = imageFileNames.get(position);
        holder.setImage(imagePath);

        holder.view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(holder.view.getContext(), DisplayImageActivity.class);
                intent.putExtra("imageUrl", imagePath);
                holder.view.getContext().startActivity(intent);
            }
        });



    }

    @Override
    public int getItemCount() {
        return imageFileNames.size();
    }

    public static class ImageViewHolder extends RecyclerView.ViewHolder {
        private ImageView imageView;
        View view;

        public ImageViewHolder(@NonNull View itemView) {
            super(itemView);
            view=itemView;
            imageView = itemView.findViewById(R.id.imageView);
        }

        public void setImage(String imagePath) {
            Bitmap bitmap = BitmapFactory.decodeFile(imagePath);
            imageView.setImageBitmap(bitmap);
        }
    }
}